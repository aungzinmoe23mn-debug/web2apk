-- Create a PRIVATE Storage bucket named build-files in Supabase before running this.
create table if not exists public.build_jobs (
  id text primary key,
  user_id text not null default 'owner',
  status text not null default 'queued',
  app_name text not null,
  package_id text not null,
  apk_path text,
  error_message text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
alter table public.build_jobs enable row level security;
-- No public policies: access is through the backend service-role key only.
