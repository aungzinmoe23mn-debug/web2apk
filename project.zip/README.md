# Personal HTML-to-APK Converter (phone-friendly)

This is a **starter project** for a personal website that accepts a ZIP containing a web page, triggers an Android WebView APK build on GitHub Actions, stores the APK in private Supabase Storage, and offers a download link.

**Honesty note:** this package has not been deployed or tested end-to-end against your accounts. It must be configured first. The generated APK is a debug APK for personal use, not a Play Store release.

## What the ZIP must contain
- `index.html` at the ZIP root (not nested inside another folder)
- CSS, JavaScript, images and assets referenced with relative paths
- Upload limit 20 MB; expanded site limit 100 MB

## Required services
1. **GitHub**: stores source code and runs Android builds.
2. **Supabase**: private Storage for source ZIPs and output APKs.
3. **Node web host** (for example Render): serves the converter website and receives uploads.

The website is served by the backend itself, so no separate GitHub Pages setup or CORS configuration is needed.

## 1. Put this project in a GitHub repository
Upload all files/folders in this ZIP to the repository root, including the hidden `.github` folder. Use the default branch (normally `main`) and enable GitHub Actions.

Create a GitHub Personal Access Token with access to this repository and permission to **Contents: Read and write** (repository_dispatch requires write access). Keep it private.

## 2. Set up Supabase Storage
1. Create a Supabase project at https://supabase.com/dashboard.
2. Open Storage and create a **private** bucket named `build-files`.
3. Open SQL Editor and run the contents of `supabase.sql`.
4. From Project Settings → API, copy the Project URL and `service_role` key. The service-role key is secret; do not put it in the website or chat.

## 3. Deploy the backend website
Deploy this GitHub repository to a Node host such as Render. Set the **Root Directory** to `backend` and use:
- Build command: `npm install`
- Start command: `npm start`

Set these environment variables on the backend host:
- `APP_PASSWORD`: a long password only you know
- `SESSION_SECRET`: a random secret of at least 32 characters
- `BACKEND_CALLBACK_SECRET`: a different random secret of at least 32 characters
- `SUPABASE_URL`: your Supabase project URL
- `SUPABASE_SERVICE_ROLE_KEY`: Supabase `service_role` key
- `GITHUB_OWNER`: your GitHub username or organization
- `GITHUB_REPO`: exact repository name
- `GITHUB_TOKEN`: GitHub token described above

After deployment, open the backend HTTPS URL. It should show the HTML-to-APK login page. `/health` should return `{"ok":true}`.

## 4. Add GitHub Actions secrets
In the repository: Settings → Secrets and variables → Actions → New repository secret. Add:
- `BACKEND_CALLBACK_URL`: backend HTTPS URL, e.g. `https://your-service.onrender.com` (no trailing slash)
- `BACKEND_CALLBACK_SECRET`: exactly the same value as the backend environment variable
- `SUPABASE_URL`: same Supabase project URL
- `SUPABASE_SERVICE_ROLE_KEY`: same Supabase `service_role` key

Make sure Actions are enabled and the workflow file `.github/workflows/build-apk.yml` is on the default branch.

## 5. Use the converter
1. Open the backend HTTPS URL on your Android phone.
2. Enter `APP_PASSWORD`.
3. Select a ZIP with `index.html` at its root.
4. Set app name and package ID (example `com.personal.myapp`).
5. Tap Convert to APK and wait.
6. Download the APK when completed. Android may ask you to allow installation from the browser or file manager.

## Important limits
- The build may take several minutes.
- Free backend hosts can sleep, so first load may be slow.
- GitHub Actions usage limits depend on your plan.
- Some websites require permissions, external APIs or online access that a basic WebView app does not provide.
- If a build fails, inspect the GitHub repository's Actions logs. Never share secrets in screenshots or chats.
