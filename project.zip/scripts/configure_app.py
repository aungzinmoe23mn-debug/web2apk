import sys, pathlib, re, xml.etree.ElementTree as ET
name=(sys.argv[1] if len(sys.argv)>1 else "My Web App").strip()[:40] or "My Web App"
p=pathlib.Path("app/src/main/res/values/strings.xml")
p.parent.mkdir(parents=True,exist_ok=True)
escaped=name.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;")
p.write_text(f'<?xml version="1.0" encoding="utf-8"?>\n<resources><string name="app_name">{escaped}</string></resources>\n')
