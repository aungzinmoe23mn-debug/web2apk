import os, sys, zipfile, shutil, pathlib
src, dest = sys.argv[1], sys.argv[2]
if os.path.exists(dest): shutil.rmtree(dest)
os.makedirs(dest, exist_ok=True)
with zipfile.ZipFile(src) as z:
    entries=z.infolist()
    if len(entries)>3000: raise SystemExit("ZIP contains too many files")
    total=0
    for i in entries:
        name=i.filename.replace("\\","/")
        p=pathlib.PurePosixPath(name)
        if p.is_absolute() or ".." in p.parts or (p.parts and ":" in p.parts[0]):
            raise SystemExit("Unsafe ZIP path detected")
        total += i.file_size
        if total > 100*1024*1024: raise SystemExit("Uncompressed site exceeds 100 MB")
        if i.file_size > 30*1024*1024: raise SystemExit("A file exceeds 30 MB")
    if "index.html" not in [i.filename.replace("\\","/") for i in entries]:
        raise SystemExit("ZIP must contain index.html at its root")
    z.extractall(dest)
print("Extracted website safely")
