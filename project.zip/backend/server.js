import express from 'express';
import multer from 'multer';
import crypto from 'node:crypto';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createClient } from '@supabase/supabase-js';
import yauzl from 'yauzl';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const required = ['APP_PASSWORD','SESSION_SECRET','BACKEND_CALLBACK_SECRET','SUPABASE_URL','SUPABASE_SERVICE_ROLE_KEY','GITHUB_OWNER','GITHUB_REPO','GITHUB_TOKEN'];
for (const k of required) if (!process.env[k]) console.warn(`Missing environment variable: ${k}`);
const app = express();
app.disable('x-powered-by');
app.use(express.json({limit:'1mb'}));
const upload = multer({storage:multer.memoryStorage(), limits:{fileSize:20*1024*1024, files:1}});
const supabase = createClient(process.env.SUPABASE_URL || 'https://invalid.supabase.co', process.env.SUPABASE_SERVICE_ROLE_KEY || 'missing');
const b64 = x => Buffer.from(x).toString('base64url');
function sign(payload) {
  const body=b64(JSON.stringify(payload));
  const sig=crypto.createHmac('sha256',process.env.SESSION_SECRET).update(body).digest('base64url');
  return `${body}.${sig}`;
}
function verify(token) {
  const [body,sig]=String(token||'').split('.');
  if(!body||!sig || !process.env.SESSION_SECRET) return false;
  const expected=crypto.createHmac('sha256',process.env.SESSION_SECRET).update(body).digest();
  let got; try { got=Buffer.from(sig,'base64url'); } catch { return false; }
  if(got.length!==expected.length || !crypto.timingSafeEqual(got,expected)) return false;
  try { const p=JSON.parse(Buffer.from(body,'base64url').toString()); return p.sub==='owner' && p.exp>Date.now() ? p : false; } catch { return false; }
}
function auth(req,res,next) {
  const token=(req.headers.authorization||'').replace(/^Bearer\s+/i,'');
  if(!verify(token)) return res.status(401).json({error:'Login expired. Please log in again.'});
  req.owner='owner'; next();
}
function zipHasRootIndex(buf) {
  return new Promise((resolve,reject)=>{
    yauzl.fromBuffer(buf,{lazyEntries:true,decodeStrings:true},(err,zip)=>{
      if(err) return reject(err);
      let found=false, count=0, settled=false;
      const fail=e=>{if(!settled){settled=true;try{zip.close()}catch{};reject(e)}};
      zip.on('entry', e=>{
        count++;
        if(count>3000) return fail(new Error('ZIP has too many entries (limit 3000).'));
        const name=e.fileName.replace(/\\/g,'/');
        if(name.startsWith('/') || name.split('/').includes('..')) return fail(new Error('Unsafe path in ZIP.'));
        if(name==='index.html') found=true;
        zip.readEntry();
      });
      zip.on('end',()=>{if(!settled){settled=true;resolve(found)}});
      zip.on('error',fail);
      zip.readEntry();
    });
  });
}
app.get('/health',(_,res)=>res.json({ok:true}));
app.post('/api/login',(req,res)=>{
  const pass=String(req.body?.password||'');
  const a=Buffer.from(pass), b=Buffer.from(process.env.APP_PASSWORD||'');
  if(!b.length || a.length!==b.length || !crypto.timingSafeEqual(a,b)) return res.status(401).json({error:'Incorrect password.'});
  res.json({token:sign({sub:'owner',exp:Date.now()+12*60*60*1000})});
});
app.post('/api/build',auth,upload.single('zip'),async(req,res)=>{
  let jobId, zipPath;
  try {
    if(!req.file) return res.status(400).json({error:'Choose a ZIP file first.'});
    if(!req.file.originalname.toLowerCase().endsWith('.zip')) return res.status(400).json({error:'Please upload a .zip file.'});
    if(!(await zipHasRootIndex(req.file.buffer))) return res.status(400).json({error:'ZIP must contain index.html at the root.'});
    const appName=String(req.body.appName||'My Web App').trim().slice(0,40).replace(/[<>"]/g,'') || 'My Web App';
    const packageId=String(req.body.packageId||'com.personal.webapp').trim().toLowerCase();
    if(!/^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*){1,5}$/.test(packageId)) return res.status(400).json({error:'Package ID format is invalid. Example: com.example.myapp'});
    jobId=crypto.randomUUID(); zipPath=`uploads/${jobId}.zip`;
    const {error:upErr}=await supabase.storage.from('build-files').upload(zipPath,req.file.buffer,{contentType:'application/zip',upsert:false});
    if(upErr) throw upErr;
    const {data:signed,error:sErr}=await supabase.storage.from('build-files').createSignedUrl(zipPath,3600);
    if(sErr) throw sErr;
    const {error:dbErr}=await supabase.from('build_jobs').insert({id:jobId,user_id:'owner',status:'queued',app_name:appName,package_id:packageId});
    if(dbErr) throw dbErr;
    const dispatch=await fetch(`https://api.github.com/repos/${process.env.GITHUB_OWNER}/${process.env.GITHUB_REPO}/dispatches`,{
      method:'POST',headers:{Authorization:`Bearer ${process.env.GITHUB_TOKEN}`,'Accept':'application/vnd.github+json','X-GitHub-Api-Version':'2022-11-28','Content-Type':'application/json'},
      body:JSON.stringify({event_type:'build_html_apk',client_payload:{job_id:jobId,source_url:signed.signedUrl,app_name:appName,package_id:packageId}})
    });
    if(!dispatch.ok) throw new Error(`GitHub dispatch failed (${dispatch.status}). Check GITHUB_TOKEN permissions and Actions.`);
    await supabase.from('build_jobs').update({status:'building',updated_at:new Date().toISOString()}).eq('id',jobId);
    res.json({jobId});
  } catch(e) {
    if(jobId) await supabase.from('build_jobs').update({status:'failed',error_message:String(e.message||e).slice(0,500),updated_at:new Date().toISOString()}).eq('id',jobId);
    res.status(500).json({error:String(e.message||'Build request failed').slice(0,500)});
  }
});
app.get('/api/jobs/:id',auth,async(req,res)=>{
  const {data,error}=await supabase.from('build_jobs').select('id,status,app_name,package_id,error_message,created_at').eq('id',req.params.id).eq('user_id','owner').maybeSingle();
  if(error) return res.status(500).json({error:'Could not read job status.'});
  if(!data) return res.status(404).json({error:'Job not found.'});
  res.json(data);
});
app.get('/api/jobs/:id/download',auth,async(req,res)=>{
  const {data,error}=await supabase.from('build_jobs').select('status,apk_path').eq('id',req.params.id).eq('user_id','owner').maybeSingle();
  if(error||!data) return res.status(404).json({error:'Job not found.'});
  if(data.status!=='completed'||!data.apk_path) return res.status(409).json({error:'APK is not ready yet.'});
  const {data:signed,error:sErr}=await supabase.storage.from('build-files').createSignedUrl(data.apk_path,300);
  if(sErr) return res.status(500).json({error:'Could not create APK download link.'});
  res.json({url:signed.signedUrl});
});
app.post('/api/callback',async(req,res)=>{
  if(!process.env.BACKEND_CALLBACK_SECRET || req.headers['x-callback-secret']!==process.env.BACKEND_CALLBACK_SECRET) return res.status(401).json({error:'Unauthorized callback.'});
  const {job_id,status,apk_path,error_message}=req.body||{};
  if(!job_id || !['completed','failed','building'].includes(status)) return res.status(400).json({error:'Invalid callback payload.'});
  if(status==='completed' && (typeof apk_path!=='string' || !apk_path.startsWith(`apks/${job_id}.apk`))) return res.status(400).json({error:'Invalid APK path.'});
  const update={status,updated_at:new Date().toISOString()};
  if(status==='completed') update.apk_path=apk_path;
  if(status==='failed') update.error_message=String(error_message||'Build failed').slice(0,500);
  const {error}=await supabase.from('build_jobs').update(update).eq('id',job_id);
  if(error) return res.status(500).json({error:'Could not update build status.'});
  res.json({ok:true});
});
app.use(express.static(path.join(__dirname,'public'),{extensions:['html']}));
app.get('*',(req,res)=>res.sendFile(path.join(__dirname,'public','index.html')));
const port=process.env.PORT||3000;
app.listen(port,()=>console.log(`Backend listening on ${port}`));
